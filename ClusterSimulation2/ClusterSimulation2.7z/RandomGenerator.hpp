#pragma once

#include <random>
#include <cstdint>

class RandomGeneratorAlt
{
public:
	RandomGeneratorAlt()
	{

	}
	RandomGeneratorAlt(std::mt19937_64 gen)
	{
		this->gen = gen;
		max_ = gen.max();
		min_ = gen.min();
	}
	auto operator()()
	{
		return max_ - gen() + min_;
	}
	auto max() {
		return gen.max();
	}
	auto min() {
		return gen.min();
	}
private:
	std::mt19937_64 gen;
	uint64_t max_;
	uint64_t min_;
};
