#pragma once
#include "xoshiro.hpp"
#include <random>

class ExponentialDistribution
{
public:
	ExponentialDistribution();
	ExponentialDistribution(double lambda);
	
	double lambda;
	double operator()();
	double altGen();

private:
	xoshiro256plus gen1;
	xoshiro256plus gen2;
	double max;
};

