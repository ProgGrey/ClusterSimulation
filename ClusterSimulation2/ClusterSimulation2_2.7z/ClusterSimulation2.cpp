﻿// ClusterSimulation2.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//
#include <iostream>
#include <omp.h>
#include "Cluster.hpp"
#include "DynamicArray.hpp"

using namespace std;

void experiment_095()
{
    uint64_t N = 1000;
    double p_l[] = { 0.1, 0.3,0.5,0.7,0.9 };
    double p_h[] = { 0.1, 0.3,0.5,0.7,0.9 };
    double lambda[5][5] = {{1.256569, 1.150595, 1.126360, 1.115595, 1.109500},
                          {1.474708, 1.257769, 1.197080, 1.168478, 1.151805},
                          {1.608988, 1.344532, 1.258753, 1.216224, 1.190777},
                          {1.699974, 1.416217, 1.313022, 1.259559, 1.226806 },
                          {1.765699, 1.476447, 1.361153, 1.299076, 1.260220 }};
    #pragma omp parallel for num_threads(10) schedule(dynamic)
    for (int t = 0; t < 25; t++) {
        int i = t / 5;
        int j = t % 5;
        double* check = new double[100];
        double* result = new double[N];
        for (int r = 0; r < 100; r++) {
            check[r] = 0;
        }
        double D = 0;
        double M = 0;
        // Запустим симуляцию и соберём данные
        for (int k = 0; k < N/2; k++) {
            Cluster* cl = new Cluster(0.95 * lambda[i][j], 2, 1, p_h[i], p_l[j], 2);
            cl->simulate(1000000, 100000, 100);
            for (int r = 0; r < 100; r++) {
                check[r] += cl->meanAppsInQueue[r];
            }
            result[k] = cl->meanAppsInQueue[99];
            cl->init(0.95 * lambda[i][j], 2, 1, p_h[i], p_l[j], 2);
            cl->useAlternativeGenertors();
            cl->simulate(1000000, 100000, 100);
            for (int r = 0; r < 100; r++) {
                check[r] += cl->meanAppsInQueue[r];
            }
            result[k + N/2] = cl->meanAppsInQueue[99];
            delete cl;
        }
        // Вычислим матожидание
        for (int k = 0; k < N; k++) {
            M += result[k];
        }
        M /= N;
        // Вычислим дисперсию
        for (int k = 0; k < N; k++) {
            D += ((result[k] - M) * (result[k] - M));
        }
        D /= N - 1;
        // Теперь выведем всё на экран
        #pragma omp critical
        {
            cout << "D[" << i + 1 << ", " << j + 1 << "] = " << D << endl;
            cout << "M[" << i + 1 << ", " << j + 1 << "] = " << M << endl;
            cout << "x = c(";
            for (int k = 0; k < 99; k++) {
                cout << check[k] / N << ", ";
            }
            cout << check[99] / N << ")" << endl;
            cout << "y = adf.test(x, alternative=\"stationary\")" << endl;
            cout << "result095_p[ " << i + 1 << ", " << j + 1 << "] = y$p.value" << endl;
            cout << "result095_s[ " << i + 1 << ", " << j + 1 << "] = y$statistic" << endl;

        }
        delete[] check;
        delete[] result;
    }
}

void experiment_105()
{
    double p_l[] = { 0.1, 0.3,0.5,0.7,0.9 };
    double p_h[] = { 0.1, 0.3,0.5,0.7,0.9 };
    double lambda[5][5] = { {1.256569, 1.150595, 1.126360, 1.115595, 1.109500},
                          {1.474708, 1.257769, 1.197080, 1.168478, 1.151805},
                          {1.608988, 1.344532, 1.258753, 1.216224, 1.190777},
                          {1.699974, 1.416217, 1.313022, 1.259559, 1.226806 },
                          {1.765699, 1.476447, 1.361153, 1.299076, 1.260220 } };
    #pragma omp parallel for num_threads(10) schedule(dynamic)
    for (int t = 0; t < 25; t++) {
        int i = t / 5;
        int j = t % 5;
        double* check = new double[100];
        for (int r = 0; r < 100; r++) {
            check[r] = 0;
        }
        // Запустим симуляцию и соберём данные
        for (int k = 0; k < 1000; k++) {
            Cluster* cl = new Cluster(1.05 * lambda[i][j], 2, 1, p_h[i], p_l[j], 2);
            cl->simulate(1000000, 100000, 100);
            for (int r = 0; r < 100; r++) {
                check[r] += cl->meanAppsInQueue[r];
            }
            delete cl;
        }
        // Теперь выведем всё в файл
        #pragma omp critical
        {
            cout << "x = c(";
            for (int k = 0; k < 99; k++) {
                cout << check[k] / 100 << ", ";
            }
            cout << check[99] / 100 << ")" << endl;
            cout << "y = adf.test(x, alternative=\"stationary\")" << endl;
            cout << "result105_p[ " << i + 1 << ", " << j + 1 << "] = y$p.value" << endl;
            cout << "result105_s[ " << i + 1 << ", " << j + 1 << "] = y$statistic" << endl;

        }
        delete[] check;
    }
}
int main()
{
    cout << fixed;
    cout.precision(6);
    // Около 3-х секунд было раньше
    // После оптимизации: 2.5 секунды
    Cluster* cl = new Cluster(1.109500 * 0.95, 2, 1, 0.1, 0.9, 2);

    cl->simulate(1000000, 100000, 100);

    cl->printMetrics();
    delete cl;
    //*/
    //experiment_095();
    //experiment_105();
    /*
    for (int k = 0; k < 10; k++) {
        cout << cl->meanAppsInQueue[k] << "\t";
    }
    cout << endl;
    delete cl;
    cout << "#1.05" << endl;
    experiment(1.05);
    cout << "result" << endl;
    cout << "#0.95" << endl;
    experiment(0.95);
    //*/
    return 0;
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.

